<?php
/**
 * @category  Hackathon
 * @package   Hunt Drive
 * @author    Areous Ahmadtj.
 */

/**
* Try to increase memory limit if the script cant render big images.
*/
// ini_set('memory_limit', '512M');

require_once 'hunt-admin/config.php';
session_name($_CONFIG["session_name"]);
session_start();
require_once 'hunt-admin/class.php'; 
if (!GateKeeper::isAccessAllowed()) {
    die('access denied');
}
$imageServer = new ImageServer();
$imageServer->showImage();