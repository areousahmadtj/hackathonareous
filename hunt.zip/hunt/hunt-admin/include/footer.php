<?php
/**
 * @category  Hackathon
 * @package   Hunt Drive
 * @author    Areous Ahmadtj.
 */ ?>
 <footer class="footer">
    <div class="container">
        <span class="pull-left"><a href="./">
            <?php print $setUp->getConfig("appname"); ?> </a> 
            &copy; <?php echo date('Y'); ?>
        </span>
    </div>
</footer>