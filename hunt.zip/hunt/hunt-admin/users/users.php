<?php

 $_USERS = array (
  0 => 
  array (
    'name' => 'areous',
    'pass' => '$1$SQohRO5g$GiudcUbEZ.4X1c2DobxfR/',
    'role' => 'superadmin',
  ),
);
